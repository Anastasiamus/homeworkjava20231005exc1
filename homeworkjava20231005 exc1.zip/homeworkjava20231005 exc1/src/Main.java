import com.sun.jdi.IntegerValue;

import java.util.Random;

public class Main {
    public static void main(String[] args) {

        Random rnd = new Random();
        String s ="65";
        String.valueOf(s);

        int i = rnd.nextInt(64);
        byte b = Byte.parseByte(s);
        long l = Long.parseLong(s);
        short sh = Short.parseShort(s);
        char c = (char)Integer.parseInt(s);




        



    }
}